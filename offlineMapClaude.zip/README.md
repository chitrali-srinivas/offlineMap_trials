# FarmMap

Farm boundary mapping platform — Admin Dashboard + Surveyor PWA.

## Deploy to Cloud Run (Source Deploy)

1. Push this repo to GitHub
2. In Cloud Run: New Service → Deploy from source → connect your GitHub repo
3. Cloud Run will auto-detect the Dockerfile and build

## First-time Setup

1. Visit the app URL → login with `srini / srini`
2. Click **Settings** tab
3. Run the SQL shown in Settings in your Supabase SQL Editor
4. Paste your keys: Supabase URL, Supabase anon key, Mapbox token, Google Maps key
5. Click **Save & Apply Settings**

## Usage

### Admin
- Add Village → fill location fields → select Mapbox or Google basemap
- Preview Map → Generate Boundary (pulls from OpenStreetMap)
- Rate quality → if poor, switch source and regenerate
- Save Village

### Surveyor
- Open `/surveyor` on mobile browser
- Tap "Add to Home Screen" for PWA install
- Select village → boundary overlays on satellite map
- Works offline after first load

## Stack
- Node.js + Express
- Leaflet.js for maps
- Supabase (PostgreSQL) for persistence
- OpenStreetMap / Nominatim / Overpass for boundary data
